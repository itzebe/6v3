import type { Enrichment, Launch, ScoreResult } from "./types.js";
import { config } from "./config.js";

const suspicious = [
  "airdrop", "claim", "free", "scam", "test", "presale", "guaranteed", "100x",
];

export function scoreLaunch(launch: Launch, data: Enrichment): ScoreResult {
  let score = 0;
  const reasons: string[] = [];
  const risks: string[] = [];

  const text = `${launch.name} ${launch.symbol}`.toLowerCase();

  if (data.metadata?.image) {
    score += 20;
    reasons.push("metadata has an image");
  } else if (config.requireMetadata) {
    score -= 20;
    risks.push("metadata image missing");
  }

  if (data.metadata?.website || data.metadata?.twitter || data.metadata?.telegram) {
    score += 10;
    reasons.push("metadata has social/web links");
  }

  if (data.creatorTxs > 20) {
    score += 15;
    reasons.push("creator has 20+ previous transactions");
  } else if (data.creatorTxs >= 5) {
    score += 10;
    reasons.push("creator has 5–20 previous transactions");
  } else if (data.creatorTxs >= 2) {
    score += 5;
    reasons.push("creator has 2–4 previous transactions");
  } else {
    risks.push("creator has very little transaction history");
  }

  if (!suspicious.some(word => text.includes(word))) {
    score += 10;
    reasons.push("name/symbol passed basic spam filter");
  }

  if (data.graduated === false) {
    score += 10;
    reasons.push("still on bonding curve");
  }

  if (typeof data.progressPct === "number" && data.progressPct >= 10 && data.progressPct <= 60) {
    score += 5;
    reasons.push(`bonding curve progress is ${data.progressPct.toFixed(1)}%`);
  }

  if (!launch.isMayhemMode) {
    score += 5;
    reasons.push("mayhem mode is off");
  }

  for (const word of config.blocklist) {
    if (text.includes(word)) {
      score -= 25;
      risks.push(`blocklist match: ${word}`);
      break;
    }
  }

  if (suspicious.some(word => text.includes(word))) {
    score -= 25;
    risks.push("suspicious launch keyword");
  }

  return {
    score: Math.max(0, Math.min(100, score)),
    reasons: reasons.slice(0, 5),
    risks: risks.slice(0, 4),
  };
}
