import { Connection, PublicKey } from "@solana/web3.js";
import { OnlinePumpSdk, bondingCurveGraduationProgress, bondingCurveMarketCap } from "@pump-fun/pump-sdk";
import type { Enrichment, Launch } from "./types.js";

function safeNumber(value: any): number | undefined {
  if (value == null) return undefined;
  try {
    const n = Number(value.toString());
    return Number.isFinite(n) ? n : undefined;
  } catch {
    return undefined;
  }
}

async function fetchMetadata(uri: string) {
  if (!uri || !/^https?:\/\//i.test(uri)) return undefined;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    const res = await fetch(uri, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) return undefined;
    const json: any = await res.json();
    return {
      image: typeof json.image === "string" ? json.image : undefined,
      website: typeof json.website === "string" ? json.website : undefined,
      twitter: typeof json.twitter === "string" ? json.twitter : undefined,
      telegram: typeof json.telegram === "string" ? json.telegram : undefined,
    };
  } catch {
    return undefined;
  }
}

export async function enrichLaunch(
  connection: Connection,
  sdk: OnlinePumpSdk,
  launch: Launch
): Promise<Enrichment> {
  const creator = new PublicKey(launch.creator);
  const mint = new PublicKey(launch.mint);

  const [creatorSigs, metadata, curve] = await Promise.all([
    connection.getSignaturesForAddress(creator, { limit: 100 }),
    fetchMetadata(launch.uri),
    sdk.fetchBondingCurve(mint).catch(() => null),
  ]);

  const creatorTxs = creatorSigs.length;

  if (!curve) {
    return { creatorTxs, metadata };
  }

  let marketCapSol: number | undefined;
  let progressPct: number | undefined;

  try {
    const marketCap = bondingCurveMarketCap(curve as any);
    marketCapSol = Number(marketCap.toString()) / 1e9;

    const progress = bondingCurveGraduationProgress({
      realSolReserves: curve.realSolReserves,
      realTokenReserves: curve.realTokenReserves,
    });
    progressPct = Math.max(0, Math.min(100, Number(progress) * 100));
  } catch {
    // Leave optional analytics undefined.
  }

  return {
    creatorTxs,
    metadata,
    marketCapSol,
    progressPct,
    graduated: Boolean(curve.complete),
  };
}
