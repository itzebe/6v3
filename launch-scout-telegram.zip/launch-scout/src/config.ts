import "dotenv/config";

function num(name: string, fallback: number): number {
  const value = Number(process.env[name]);
  return Number.isFinite(value) ? value : fallback;
}

export const config = {
  telegramToken: process.env.TELEGRAM_BOT_TOKEN ?? "",
  adminChatId: process.env.ADMIN_CHAT_ID ?? "",
  alertChatId: process.env.ALERT_CHAT_ID || process.env.ADMIN_CHAT_ID || "",
  rpcUrl: process.env.SOLANA_RPC_URL ?? "https://api.mainnet-beta.solana.com",
  wsUrl: process.env.SOLANA_WS_URL || undefined,
  minScore: num("MIN_SCORE", 65),
  maxAlertsPerMinute: num("MAX_ALERTS_PER_MINUTE", 20),
  strictMode: process.env.STRICT_MODE === "true",
  minCreatorTxs: num("MIN_CREATOR_TXS", 1),
  requireMetadata: process.env.REQUIRE_METADATA !== "false",
  blocklist: new Set(
    (process.env.BLOCKLIST ?? "airdrop,claim,free,scam,test")
      .split(",")
      .map(x => x.trim().toLowerCase())
      .filter(Boolean)
  ),
};
