import bs58 from "bs58";
import { PublicKey } from "@solana/web3.js";
import type { Launch } from "./types.js";

export const PUMP_PROGRAM_ID = new PublicKey(
  "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
);

const LEGACY_CREATE = Buffer.from([24, 30, 200, 40, 5, 28, 7, 119]);
const CREATE_V2 = Buffer.from([214, 144, 76, 236, 95, 139, 49, 180]);

function readU32(buf: Buffer, offset: number): { value: number; offset: number } {
  return { value: buf.readUInt32LE(offset), offset: offset + 4 };
}

function readString(buf: Buffer, offset: number): { value: string; offset: number } {
  const len = buf.readUInt32LE(offset);
  const start = offset + 4;
  const end = start + len;
  if (end > buf.length) throw new Error("Invalid Borsh string");
  return { value: buf.subarray(start, end).toString("utf8"), offset: end };
}

function parseCreateData(data: string): {
  name: string; symbol: string; uri: string; creator: string; isMayhemMode: boolean;
} | null {
  const raw = Buffer.from(bs58.decode(data));
  if (raw.length < 8) return null;

  const disc = raw.subarray(0, 8);
  const isLegacy = disc.equals(LEGACY_CREATE);
  const isV2 = disc.equals(CREATE_V2);
  if (!isLegacy && !isV2) return null;

  let offset = 8;
  const n = readString(raw, offset); offset = n.offset;
  const s = readString(raw, offset); offset = s.offset;
  const u = readString(raw, offset); offset = u.offset;

  if (offset + 32 > raw.length) throw new Error("Creator missing");
  const creator = new PublicKey(raw.subarray(offset, offset + 32)).toBase58();
  offset += 32;

  let isMayhemMode = false;
  if (isV2 && offset < raw.length) {
    isMayhemMode = raw[offset] !== 0;
  }

  return {
    name: n.value,
    symbol: s.value,
    uri: u.value,
    creator,
    isMayhemMode,
  };
}

export function parseLaunchFromTransaction(
  tx: any,
  signature: string,
  timestamp: number
): Launch | null {
  const instructions = tx?.transaction?.message?.instructions ?? [];
  for (const ix of instructions) {
    if (!ix?.programId || ix.programId !== PUMP_PROGRAM_ID.toBase58()) continue;
    if (!ix.data || !Array.isArray(ix.accounts) || ix.accounts.length === 0) continue;

    try {
      const parsed = parseCreateData(ix.data);
      if (!parsed) continue;

      const mint = String(ix.accounts[0]);
      return {
        signature,
        mint,
        ...parsed,
        timestamp,
      };
    } catch {
      // Ignore malformed/non-create instructions.
    }
  }
  return null;
}
