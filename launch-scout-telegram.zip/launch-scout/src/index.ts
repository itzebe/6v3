import { Connection } from "@solana/web3.js";
import { OnlinePumpSdk } from "@pump-fun/pump-sdk";
import { config } from "./config.js";
import { createBot } from "./bot.js";
import { PUMP_PROGRAM_ID, parseLaunchFromTransaction } from "./parser.js";
import { enrichLaunch } from "./enrich.js";
import { scoreLaunch } from "./score.js";
import { formatLaunch } from "./format.js";

if (!config.telegramToken) {
  throw new Error("Set TELEGRAM_BOT_TOKEN in .env");
}
if (!config.alertChatId) {
  throw new Error("Set ALERT_CHAT_ID or ADMIN_CHAT_ID in .env");
}

const connection = new Connection(config.rpcUrl, {
  commitment: "processed",
  wsEndpoint: config.wsUrl,
});
const sdk = new OnlinePumpSdk(connection);
const bot = createBot();

let processed = 0;
let sent = 0;
let lastEvent = 0;
const seen = new Set<string>();
const sendTimes: number[] = [];

function allowedByRateLimit(): boolean {
  const now = Date.now();
  while (sendTimes.length && now - sendTimes[0] > 60_000) sendTimes.shift();
  if (sendTimes.length >= config.maxAlertsPerMinute) return false;
  sendTimes.push(now);
  return true;
}

async function handleSignature(signature: string) {
  if (seen.has(signature)) return;
  seen.add(signature);
  if (seen.size > 10_000) {
    const first = seen.values().next().value;
    if (first) seen.delete(first);
  }

  try {
    const tx = await connection.getParsedTransaction(signature, {
      commitment: "confirmed",
      maxSupportedTransactionVersion: 0,
    });

    if (!tx?.blockTime) return;
    const launch = parseLaunchFromTransaction(tx, signature, tx.blockTime * 1000);
    if (!launch) return;

    processed++;
    lastEvent = Date.now();

    const enrichment = await enrichLaunch(connection, sdk, launch);
    const result = scoreLaunch(launch, enrichment);

    if (config.strictMode && enrichment.creatorTxs < config.minCreatorTxs) return;
    if (result.score < config.minScore) return;
    if (!allowedByRateLimit()) return;

    await bot.api.sendMessage(
      config.alertChatId,
      formatLaunch(launch, enrichment, result),
      { parse_mode: "HTML", disable_web_page_preview: true }
    );
    sent++;
    console.log(`[ALERT] ${launch.symbol} ${launch.mint} score=${result.score}`);
  } catch (error) {
    console.error("[handleSignature]", error);
  }
}

bot.command("status", async ctx => {
  const age = lastEvent ? `${Math.round((Date.now() - lastEvent) / 1000)}s ago` : "waiting";
  await ctx.reply(
    [
      "📡 <b>Launch Scout</b>",
      "",
      `Pump monitor: <b>running</b>`,
      `Detected: <b>${processed}</b>`,
      `Alerts sent: <b>${sent}</b>`,
      `Last event: <b>${age}</b>`,
      `Minimum score: <b>${config.minScore}</b>`,
      `RPC: <code>${config.rpcUrl}</code>`,
    ].join("\n"),
    { parse_mode: "HTML" }
  );
});

if (config.adminChatId) {
  bot.command("score", async ctx => {
    if (String(ctx.chat.id) !== config.adminChatId) return;
    const value = Number(ctx.match?.trim());
    if (!Number.isFinite(value) || value < 0 || value > 100) {
      await ctx.reply("Usage: /score 75");
      return;
    }
    config.minScore = value;
    await ctx.reply(`✅ Minimum score set to ${value}.`);
  });

  bot.command("minscore", async ctx => {
    if (String(ctx.chat.id) !== config.adminChatId) return;
    const value = Number(ctx.match?.trim());
    if (!Number.isFinite(value) || value < 0 || value > 100) {
      await ctx.reply("Usage: /minscore 75");
      return;
    }
    config.minScore = value;
    await ctx.reply(`✅ Minimum score set to ${value}.`);
  });

  bot.command("block", async ctx => {
    if (String(ctx.chat.id) !== config.adminChatId) return;
    const word = ctx.match?.trim().toLowerCase();
    if (!word) return ctx.reply("Usage: /block word");
    config.blocklist.add(word);
    await ctx.reply(`🚫 Added "${word}" to blocklist.`);
  });

  bot.command("unblock", async ctx => {
    if (String(ctx.chat.id) !== config.adminChatId) return;
    const word = ctx.match?.trim().toLowerCase();
    if (!word) return ctx.reply("Usage: /unblock word");
    config.blocklist.delete(word);
    await ctx.reply(`✅ Removed "${word}" from blocklist.`);
  });
}

connection.onLogs(
  PUMP_PROGRAM_ID,
  async logInfo => {
    if (logInfo.err) return;
    void handleSignature(logInfo.signature);
  },
  "processed"
);

bot.catch(err => console.error("[telegram]", err));

console.log("🚀 Launch Scout is running");
console.log(`Watching Pump program: ${PUMP_PROGRAM_ID.toBase58()}`);
console.log(`Minimum score: ${config.minScore}`);

await bot.start();
