import type { Enrichment, Launch, ScoreResult } from "./types.js";

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

function short(s: string, n = 6) {
  return s.length > n * 2 ? `${s.slice(0, n)}…${s.slice(-n)}` : s;
}

export function formatLaunch(
  launch: Launch,
  data: Enrichment,
  result: ScoreResult
): string {
  const badge = result.score >= 85 ? "🔥 HOT" : result.score >= 75 ? "🟠 WATCH" : "🟡 EARLY";
  const lines = [
    `${badge} <b>NEW PUMP LAUNCH</b>`,
    ``,
    `<b>${esc(launch.name)}</b> · $${esc(launch.symbol)}`,
    `<code>${esc(short(launch.mint, 8))}</code>`,
    ``,
    `🎯 <b>Score:</b> ${result.score}/100`,
    data.marketCapSol !== undefined ? `💰 <b>Est. MC:</b> ${data.marketCapSol.toFixed(1)} SOL` : `💰 <b>MC:</b> unavailable`,
    data.progressPct !== undefined ? `📈 <b>Curve:</b> ${data.progressPct.toFixed(1)}%` : `📈 <b>Curve:</b> unavailable`,
    `👤 <b>Creator txs:</b> ${data.creatorTxs}`,
    `⚙️ <b>Mayhem:</b> ${launch.isMayhemMode ? "ON" : "OFF"}`,
    ``,
    result.reasons.length ? `✅ ${result.reasons.join(" · ")}` : "",
    result.risks.length ? `⚠️ ${result.risks.join(" · ")}` : "",
    ``,
    `🔗 <a href="https://pump.fun/coin/${encodeURIComponent(launch.mint)}">Pump</a> · <a href="https://solscan.io/token/${encodeURIComponent(launch.mint)}">Solscan</a> · <a href="https://dexscreener.com/solana/${encodeURIComponent(launch.mint)}">Chart</a>`,
    `🧾 <a href="https://solscan.io/tx/${encodeURIComponent(launch.signature)}">Launch TX</a>`,
  ];

  return lines.filter(Boolean).join("\n");
}

export function formatTest(): string {
  return [
    "🧪 <b>Launch Scout test</b>",
    "",
    "Telegram delivery is working.",
    "The monitor is alert-only; it never executes trades.",
  ].join("\n");
}
