import { Bot } from "grammy";
import { config } from "./config.js";
import { formatTest } from "./format.js";

export function createBot() {
  if (!config.telegramToken) throw new Error("TELEGRAM_BOT_TOKEN is missing");

  const bot = new Bot(config.telegramToken);

  bot.command("start", ctx =>
    ctx.reply(
      "🚀 <b>Launch Scout</b>\n\nI watch Pump launches and send only launches that pass your score/filter.\n\nUse /help for commands.",
      { parse_mode: "HTML" }
    )
  );

  bot.command("help", ctx =>
    ctx.reply(
      [
        "<b>Launch Scout</b>",
        "",
        "/status — monitor status",
        "/score 75 — set minimum score",
        "/minscore 75 — same",
        "/block word — add a block word",
        "/unblock word — remove a block word",
        "/test — test Telegram delivery",
      ].join("\n"),
      { parse_mode: "HTML" }
    )
  );

  bot.command("test", ctx => ctx.reply(formatTest(), { parse_mode: "HTML" }));

  return bot;
}
