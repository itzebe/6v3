export type Launch = {
  signature: string;
  mint: string;
  name: string;
  symbol: string;
  uri: string;
  creator: string;
  isMayhemMode: boolean;
  timestamp: number;
};

export type Enrichment = {
  marketCapSol?: number;
  progressPct?: number;
  graduated?: boolean;
  creatorTxs: number;
  metadata?: {
    image?: string;
    website?: string;
    twitter?: string;
    telegram?: string;
  };
};

export type ScoreResult = {
  score: number;
  reasons: string[];
  risks: string[];
};
