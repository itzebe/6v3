# Launch Scout — Telegram launch monitor

A custom Solana/Pump launch monitor built for early-launch research. It **does not buy or sell tokens**.

It listens for Pump program transactions, detects legacy `create` and current `create_v2` coin-creation instructions, enriches the launch with on-chain bonding-curve data and metadata, scores it, and sends only qualifying launches to Telegram.

## What it does

- Detects Pump launches in real time through Solana WebSocket logs.
- Parses token name, symbol, metadata URI and creator from the creation instruction.
- Fetches bonding-curve state using `@pump-fun/pump-sdk`.
- Calculates current market cap and graduation progress when available.
- Checks creator transaction history.
- Checks token metadata for image/social/website links.
- Applies a configurable score and blocklist.
- Sends a compact Telegram alert with links to Pump, Solscan and DexScreener.
- Includes `/status`, `/score`, `/minscore`, `/block`, `/unblock`, `/test`, `/start`, `/help`.

## Safety

This is an **alert/research bot only**. There is no private key, wallet, swap execution, sniper, or automatic trade logic.

Do not put a wallet private key into this project.

## Setup

1. Create a Telegram bot with `@BotFather` using `/newbot`. Telegram gives you a bot token; keep it secret.
2. Copy `.env.example` to `.env`.
3. Set `TELEGRAM_BOT_TOKEN`.
4. Set `ADMIN_CHAT_ID` to your Telegram numeric chat ID. For a first run, you can temporarily leave it blank and use `/status` after starting, then set it.
5. Use a reliable Solana RPC for production.
6. Install and run:

```bash
npm install
npm run dev
```

Production:

```bash
npm run build
npm start
```

## Recommended first configuration

```env
MIN_SCORE=65
MAX_ALERTS_PER_MINUTE=20
REQUIRE_METADATA=true
MIN_CREATOR_TXS=1
BLOCKLIST=airdrop,claim,free,scam,test
```

## Telegram commands

- `/start` — start the bot
- `/help` — command list
- `/status` — monitor status and current settings
- `/score 75` — change minimum score
- `/minscore 75` — same as above
- `/block word` — add a blocklisted word
- `/unblock word` — remove a blocklisted word
- `/test` — send a test message

Only `ADMIN_CHAT_ID` can change settings.

## Scoring model

The first version deliberately avoids pretending that a score is a prediction of price.

It scores **observable launch quality signals**:

- +20 metadata contains a usable image
- +10 website/social metadata exists
- +15 creator has more than 20 previous transactions
- +10 creator has 5–20 previous transactions
- +5 creator has 2–4 previous transactions
- +10 token name/symbol is not suspicious
- +10 token is still on the bonding curve
- +5 progress is between 10% and 60%
- +5 mayhem mode is disabled
- -25 suspicious launch keywords
- -20 missing metadata when metadata is required

The score is a **filtering heuristic**, not financial advice or a guarantee.

## Important implementation note

Pump's official program is currently:

`6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`

The monitor supports both the older `create` discriminator and current `create_v2` discriminator so it can recognize both forms.

## Next upgrades

Good next additions are:

1. Holder concentration.
2. First 30/60/120 second buy-vs-sell flow.
3. Creator wallet reuse detection.
4. Creator's previous launch performance.
5. Social/X enrichment.
6. Separate "WATCH", "HOT" and "IGNORE" channels.
7. Persistent SQLite settings.
8. Helius/Yellowstone gRPC for lower-latency event ingestion.

